int area(w, h) int w, h; { return w * h; } int main(void) { return area(6, 7) - 42; }
