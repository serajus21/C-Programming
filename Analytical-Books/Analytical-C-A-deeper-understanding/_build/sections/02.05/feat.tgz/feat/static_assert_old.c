int main(void) { _Static_assert(sizeof(int) >= 2, "int too small"); return 0; }
