static const unsigned char data[] = {
#embed "/etc/hostname"
}; int main(void) { return sizeof data == 0; }
