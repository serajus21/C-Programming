int main(void) { int a = 3; typeof(a) b = a; return b - 3; }
