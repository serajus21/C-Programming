int main(void) { long long big = 1; return (int)(big - 1); }
