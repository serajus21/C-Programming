int main(void) { bool ok = true; return !ok; }
