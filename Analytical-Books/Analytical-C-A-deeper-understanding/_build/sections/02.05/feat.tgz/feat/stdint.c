#include <stdint.h>
int main(void) { uint8_t x = 255; return x - 255; }
