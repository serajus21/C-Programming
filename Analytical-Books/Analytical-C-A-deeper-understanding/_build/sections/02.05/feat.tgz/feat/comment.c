/* x */ int main(void) { return 0; } // a line comment
