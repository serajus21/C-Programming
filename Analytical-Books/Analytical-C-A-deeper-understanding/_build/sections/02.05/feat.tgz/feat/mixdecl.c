int main(void) { int a = 1; a++; int b = a; for (int i = 0; i < 2; i++) b++; return b - 4; }
