int main(void) { return 0b1010 - 10; }
