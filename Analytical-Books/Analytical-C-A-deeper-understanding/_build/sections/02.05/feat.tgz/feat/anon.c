struct s { union { int i; float f; }; }; int main(void) { struct s v; v.i = 0; return v.i; }
