int f(int n) { int a[n]; a[0] = n; return a[0]; } int main(void) { return f(3) - 3; }
