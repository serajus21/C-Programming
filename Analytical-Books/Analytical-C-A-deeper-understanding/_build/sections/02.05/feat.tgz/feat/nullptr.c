#include <stddef.h>
int main(void) { int *p = nullptr; return p != NULL; }
