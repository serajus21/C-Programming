int main(void) { auto x = 5; return x - 5; }
