int area(); int main(void) { return area(6, 7) - 42; } int area(int w, int h) { return w * h; }
