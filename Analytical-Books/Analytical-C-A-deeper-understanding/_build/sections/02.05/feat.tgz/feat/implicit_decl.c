int main(void) { return g(); } int g(void) { return 0; }
