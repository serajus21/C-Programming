int main(void) { static_assert(sizeof(int) >= 2); return 0; }
