#define kind(x) _Generic((x), int: 1, double: 2, default: 0)
int main(void) { return kind(1.0) - 2; }
