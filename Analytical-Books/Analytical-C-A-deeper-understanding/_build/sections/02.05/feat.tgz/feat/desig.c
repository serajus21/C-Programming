struct p { int x, y; }; int main(void) { struct p q = { .y = 2, .x = 1 }; int a[4] = { [3] = 7 }; return q.x + q.y + a[3] - 10; }
