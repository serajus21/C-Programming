int main(void) { long x = 1'000'000; return (int)(x - 1000000); }
