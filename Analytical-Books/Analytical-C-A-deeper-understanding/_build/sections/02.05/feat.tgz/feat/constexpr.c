constexpr int N = 4; int main(void) { int a[N] = {0}; return a[N - 1]; }
