target remote :1234
set $n = 0
while $pc != 0xa6
  stepi
  set $n = $n + 1
end
printf "instructions from reset to main: %d\n", $n
printf "ready = 0x%02x, count = 0x%02x\n", *(unsigned char *)0x800100, *(unsigned char *)0x800102
set $m = 0
while $pc != 0xba
  stepi
  set $m = $m + 1
end
printf "instructions from main to __stop_program: %d\n", $m
info registers r24 r25 pc SREG
stepi
stepi
info registers pc

